<template>
  <div class="my1 p1 h5 bg-light black rounded">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: "Message",
}
</script>

<style scoped>

</style>