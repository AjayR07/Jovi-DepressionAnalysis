import * as core from '@tensorflow/tfjs-core'
import * as layers from '@tensorflow/tfjs-layers'

export const tf = { ...core, ...layers }
